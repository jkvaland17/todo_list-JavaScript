let age = "55";
if (age < 10) {
  alert(" Are you Kid");
} else if (age < 10 && age > 50) {
  alert("You are Young");
} else {
  alert("Are You Old");
}
