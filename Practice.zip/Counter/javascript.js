function getElement(selection) {
  const element = document.querySelector(selection);
  if (element) {
    return element;
  }
  throw new Error(
    `Please check "${selection}" selector, no such element exists`
  );
}

class Counter {
  constructor(element, value) {
    this.counter = element;
    this.value = value;
    this.resetBtn = element.querySelector(".reset");
    this.increaseBtn = element.querySelector(".increase");
    this.decreaseBtn = element.querySelector(".decrease");
    this.changBtn = element.querySelector(".chang");
    this.valueDOM = element.querySelector(".value");
    this.valueDOM.textContent = this.value;
    this.increase = this.increase.bind(this);
    this.decrease = this.decrease.bind(this);
    this.reset = this.reset.bind(this);
    this.chang = this.chang.bind(this);

    this.increaseBtn.addEventListener("click", this.increase);
    this.decreaseBtn.addEventListener("click", this.decrease);
    this.resetBtn.addEventListener("click", this.reset);
    this.changBtn.addEventListener("click", this.chang);
  }
  increase() {
    this.value = this.value + 3;
    this.valueDOM.textContent = this.value;
  }
  decrease() {
    this.value = this.value - 5;
    this.valueDOM.textContent = this.value;
  }
  reset() {
    this.value = 5;
    this.valueDOM.textContent = this.value;
  }
  chang() {
    
    this.value = this.value * 5;
    this.valueDOM.textContent = this.value;

  }
}

const firstCounter = new Counter(getElement(".first-counter"), 0);

