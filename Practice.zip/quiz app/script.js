const questions = [
  {
    id: 0,
    q: "What is capital of india?",
    a: [
      { Text: "gandhinagar", isCorrect: false },
      { Text: "Surat", isCorrect: false },
      { Text: "Delhi", isCorrect: true },
      { Text: "Mumbai", isCorrect: false },
    ],
  },
  {
    id: 1,
    q: "What is the capital of Thailand?",
    a: [
      { Text: "Lampang", isCorrect: false },
      { Text: "phuket", isCorrect: false },
      { Text: "Ayutthaya", isCorrect: false },
      { Text: "Bangkok", isCorrect: true },
    ],
  },
  {
    id: 2,
    q: "What is the capital of Gujarat?",
    a: [
      { Text: "surat", isCorrect: false },
      { Text: "vadodara", isCorrect: false },
      { Text: "gandhinagar", isCorrect: true },
      { Text: "rajkot", isCorrect: false },
    ],
  },
];

let start = true;

function iterate(id) {
//getting result display
  let result = document.getElementsByClassName("result");
  result[0].innerText = "";

//getting q
  const question = document.getElementById("question");
//setting the q
  question.innerText = questions[id].q;

//getting the option
  
  const op1 = document.getElementById('op1');
  const op2 = document.getElementById('op2');
  const op3 = document.getElementById('op3');
  const op4 = document.getElementById('op4');

//providing option text
  op1.innerText = questions[id].a[0].Text;
  op2.innerText = questions[id].a[1].Text;
  op3.innerText = questions[id].a[2].Text;
  op4.innerText = questions[id].a[3].Text;

  //providing the true and false value

  op1.value = questions[id].a[0].isCorrect;
  op2.value = questions[id].a[1].isCorrect;
  op3.value = questions[id].a[2].isCorrect;
  op4.value = questions[id].a[3].isCorrect;

  let selected = "";

  //show section
  op1.addEventListener("click", () => {
    op1.style.backgroundColor = "lightgoldenrodyellow";
    op2.style.backgroundColor = "lightskyblue";
    op3.style.backgroundColor = "lightskyblue";
    op4.style.backgroundColor = "lightskyblue";
    selected = op1.value;
  })

  op2.addEventListener("click", () => {
    op1.style.backgroundColor = "lightskyblue";
    op2.style.backgroundColor = "lightgoldenrodyellow";
    op3.style.backgroundColor = "lightskyblue";
    op4.style.backgroundColor = "lightskyblue";
    selected = op2.value;
  });

  op3.addEventListener("click", () => {
    op1.style.backgroundColor = "lightskyblue";
    op2.style.backgroundColor = "lightskyblue";
    op3.style.backgroundColor = "lightgoldenrodyellow";
    op4.style.backgroundColor = "lightskyblue";
    selected = op3.value;
  });

  op4.addEventListener("click", () => {
    op1.style.backgroundColor = "lightskyblue";
    op2.style.backgroundColor = "lightskyblue";
    op3.style.backgroundColor = "lightskyblue";
    op4.style.backgroundColor = "lightgoldenrodyellow";
    selected = op4.value;
  });

  const evaluate = document.getElementsByClassName("evaluate");

  evaluate[0].addEventListener("click", () => {
    if (selected == "true") {
      result[0].innerHTML = "true";
      result[0].style.color = "green";
    } else {
      result[0].innerHTML = "false";
      result[0].style.color = "red";
    }
  })
}

if (start) {
  iterate("0");
}

const next = document.getElementsByClassName('next')[0];
let id = 0;

next.addEventListener("click", () => {
  start = false;
  if (id < 2) {
    id++;
    iterate(id);
    console.log(id);
  }
})