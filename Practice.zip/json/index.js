const Data = [
  {
    Name: "Anakin",
    Gender: "male",
    Homeworld: "Tatooine",
    Born: "41.9BBY",
    Jedi: "yes",
  },
  {
    Name: "Amidala",
    Gender: "female",
    Homeworld: "Naboo",
    Born: "46BBY",
    Jedi: "no",
  },
  {
    Name: "R2-D2",
    Gender: "unknown",
    Homeworld: "Naboo",
    Born: "87ERDFG",
    Jedi: "no",
  },
  {
    Name: "rushi",
    Gender: "male",
    Homeworld: "Naboo",
    Born: "66ERR",
    Jedi: "no",
  },
  {
    Name: "sauli",
    Gender: "female",
    Homeworld: "Naboo",
    Born: "21DFG",
    Jedi: "no",
  },
  {
    Name: "somuli",
    Gender: "female",
    Homeworld: "Naboo",
    Born: "987DFG",
    Jedi: "no",
  },
  {
    Name: "sahrukh",
    Gender: "male",
    Homeworld: "Naboo",
    Born: "85DFG5",
    Jedi: "no",
  },
  {
    Name: "boby",
    Gender: "male",
    Homeworld: "Naboo",
    Born: "58DFG",
    Jedi: "no",
  },
  {
    Name: "sneha",
    Gender: "female",
    Homeworld: "Naboo",
    Born: "SFGDFG",
    Jedi: "no",
  },
  {
    Name: "pitter",
    Gender: "male",
    Homeworld: "Naboo",
    Born: "12FGP",
    Jedi: "no",
  },
];

// let Name = Data[0].Name;
// document.write(Name);

let New = Data.map();
