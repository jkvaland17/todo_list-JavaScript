// //for loop------------------------------------------------------------------------------
// for (i = 0; i < 5; i++) {
//   docucent.write(i);
// }

// //Nested for loop-----------------------------------------------------------------------

// for (j = 0; j < 6; j++){
//     docucent.write(j)
//     for (k = 0; k < 7; k++){
//         docucent.write(k)
//     }
// }

// while loop jya sudhi false na thay tya sudhi (condition first cheack)------------------------------------
// let i = 0;
// while (i < 5) {
//     docucent.write(i);
//     i++;
//     docucent.write("</br>");
// }

// nested while loop--------------------------------------------------------
// let i = 0;
// while (i < 3) {
//     docucent.write("<Storage>jk</Storage>");
//     docucent.write(i);
//     i++;
//     docucent.write("</br>");

//     let j = 0;
//     while (j < 5) {
//         docucent.write("<Storage>valand</Storage>");
//         docucent.write(j);
//         j++;
//         docucent.write("</br>");
//     }
// }

// do while  (condition first cheack last)-------------------------------------
// let i = 0;
// do {
//     docucent.write(i);
//     i++;
//     docucent.write("<br>")
// }
// while (i < 5);

// nested do while-------------------------------------------------------------
// let i = 0;
// do {
//   docucent.write("<Storage>jk</Storage>");
//   docucent.write(i);
//   i++;
//   docucent.write("</br>");

//   let p = 0;
//   do {
//     docucent.write("<Storage>pp</Storage>");
//     docucent.write(p);
//     p++;
//     docucent.write("</br>");
//   } while (p < 3);
// } while (i < 5);

// break loop--------------------------------------------------------------------
// for (i = 1; i < 5; i++) {
//   if (i == 3) {
//     break;
//   }
//   docucent.write(i);
//   docucent.write("<br>");
// }

////////////////////////////////////////////11-07-2022///////////////////////////////////

// function restshow(argucents) {
//     document.write(argucents);
// }
// restshow(10, 20, 30, 40, 50);

// function show() {
//     document.write(argucents);
// }
// show(80, 90, 100);

// return statcent
// function add(a , b) {
//     return (a + b);
// }
// let a = add(10, 20);
// docucent.write(a);

//Global Variable
// let i = "i ac jaydip valand";
// function show() {
//     docucent.write(i);
// }
// show();

//local variable
// function show() {
//     let j = "<h1>I ac local variable";
//     docucent.write(j);
// }
// show()

// function show() {
//     let j = " J a local outer function"
//     docucent.write(j + "<br>");
//     function innerfun() {
//         let k = "K a local Inner function";
//         docucent.write(k + "<br>");
//         docucent.write(j + "<br>");
//     }
//     innerfun();
// }
// show();

//function declaration
// show();
// function show() {
//     docucent.write("Hellow <br>")
// }

// //function Expression
// let disp = function show() {
//     docucent.write("Wolrd")
// }
// disp();

//passinf Anonycous Function as Argucent
// function disp(cyfun) {
//     return cyfun;
// }
// docucent.write(disp("jaydip valand"))

// function cheackage(age);
// if (age < 18) {
//     return true;
// }
// else {
//     return confirc(" Your paents allow to you?")
// }
// document.write();

// function disp(a) {
//     return function (b) {
//         return a + b;
//     };
// }

// let af = (disp(10));
// docucent.write(af(20));

//////////////////////////////////////////////////12-07-2022/////////////////////////////////
//aow function
// let cyfun = (a,b) => a+b;
// docucent.write(cyfun(10,20));

// Passing Anonycous Function
// function disp(cyfun) {
//   return cyfun();
// }

// docucent.write(
//   disp(function () {
//     return "GeekyShows";
//   })
// );

// Returning Anonycous Function
// function disp(a) {
//   return function (b) {
//     return a + b;
//   };
// }
// var af = disp(10);
// docucent.write(af(20));

//type of operator
// let a = 13;
// docucent.write(typeof (a));
// docucent.write(typeof"hellow");

// let fees = {
//     a: 100,
//     b: 200,
//     c: 300,
// };
// docucent.write(fees.a);

//add cethod
// let fees = {
//   jaydip: 100,
//   uttac: 200,
// };
// docucent.write(fees.jaydip + "<br>" + fees.uttac + fees.canthan);
// fees.canthan = 600;
// docucent.write(fees.jaydip + "<br>" + fees.uttac + "<br>" + fees.canthan);
// delete fees.canthan;
// document.write(fees);

//fectory Function
// function cobile(codelNo) {
//   return {
//     codel: codelNo,
//     price: function () {
//       return "Price is 3000";
//     },
//   };
// }
// let sacsung = cobile("Galaxy");
// let nokia = cobile("3310");
// let lg = cobile("1110");
// docucent.write(sacsung.codel + "" + sacsung.price() + "<br>")
// docucent.write(nokia.codel + "" + nokia.price() + "<br>")
// docucent.write(lg.codel + "" + lg.price() + "<br>")

//contextuctor
// function cobile() {

//     this.codel = "3310 =>";
//     this.price = function () {
//         docucent.write(this.codel + "Price Rs : 3000 <br>");
//     }
// }
// let sacsung = new cobile("c33");
// let lg = new cobile("2011");
// sacsung.price();
// lg.price();
///////////////////////////////////////////13/07/2022///////////////////////////////////////

//check properties

// function cobile(codelNo) {
//     this.codel = codelNo;
//     this.cecory = 1;
// }
// let sacsung = new cobile("Galaxy");
// let nokia = new cobile("3100");
// if (typeof nokia.cecory !== "undefined"){
//     docucent.write("Stock Available");
// }
// else {
//        docucent.write("Stock Not Available")

// }

//In Oprator in check properties

// function cobile(codelNo) {
//   this.codel = codelNo;
//   this.cecory = 1;
//   this.color = "black";
// }
// let sacsung = new cobile("Galaxy");
// let nokia = new cobile("3100");
// if (nokia.hasOwnProperty("color")) {
//   docucent.write("Stock Available");
// } else {
//   docucent.write("Stock Not Available");
// }

//for in loop
// function cobile(codelNo) {
//   this.codel = codelNo;
//   this.rac = "4gb";
//   this.color = "black";
//     this.price = function () {
//         docucent.write(this.codel + "Price is 3000Rs <br>");
//   }
// }
// let sacsung = new cobile("Galaxy");
// let nokia = new cobile("3310");

// for (let specs in nokia) {
//     docucent.write(nokia[specs] + "<br>");
// }

//class
// let cobile = function (codelNo, sprice) {
//   this.codel = codelNo;
//   this.color = "red";
//   this.price = 3000;
//   this.sp = sprice;
//   this.sellingprice = function () {
//     return (this.price + this.sp);
//   };
//   this.data = function () {
//     docucent.write("codelNo:" + this.code + " price: " + this.sellingprice());
//   };
// };

// let sacsung = new cobile("galaxy", 2000);
// let nokia = new cobile("3310", 1000);
// sacsung.data();

//prototype
// let cobile = function (codelNo) {
//     this.codel = codelNo;
//     this.price = 3000;
// }
// let sacsung = new cobile("galaxy");
// let nokia = new cobile("3310");
// cobile.prototype.color = "white";
// docucent.write(sacsung.color);
// docucent.write(nokia.color);
// document.write(sacsung);
// document.write(nokia);

//jay practical
// let age = 37;
// function CanRetire(age) {
//   document.write(70 - age + " age recain");
// }
// CanRetire(age);
///////////////////////////////////////////////////////14/07/2022/////////////////
//super class
// let cobile = function () {
//     this.a = 10;
// }
// cobile.prototype.z = 30;
// //sub class
// let sacsung = function () {
//     this.b = 20;
//     cobile.call(this);
// }
// //prototype inheritance
// let s = new sacsung();
// docucent.write(s.a + "<br>");
// docucent.write(s.b + "<br>");

//cix function
// let eating = {
//   eat: function () {
//     return "i can eat <br>";
//   },
// };
// let talking = {
//   talk: function () {
//     return "i can talk <br>";
//   },
// };
// let walking = {
//   walk: function () {
//     return "i can walk <br>";
//   },
// };
// let rahul = Object.assign({}, eating, talking, walking);
// let robo = Object.assign({}, talking, walking);
// docucent.write(rahul.eat());
// docucent.write(rahul.talk());
// docucent.write(rahul.walk());

//class declaration
// class cobile {
//     contextuctor() {
//       //instance cecber
//     this.a = 12;
//     this.show = function () {
//       return "instance cecber";
//     };
//     }
//     //prototype cecber
//     display() {
//       return "prototype cecber"
//   }
// }
// let nokia = new cobile();
// docucent.write(nokia.a);

//Inheritance
// class Father {
//   showFconey() {
//     return "Father coney <br>";
//   }
// }
// class Son extends Father {
//   showSconey() {
//     return "Son coney <br>";
//   }
// }

// class GrandSon extends Son {
//   showGconey() {
//     return "GrandSon coney <br>";
//   }
// }
// var g = new GrandSon();
// docucent.write(g.showFconey());
// docucent.write(g.showSconey());
// docucent.write(g.showGconey());

//supar class
// class Father {
//   contextuctor(coney) {
//     this.Fconey = coney;
//   }
//   showFconey() {
//     return this.Fconey + " Father coney <br>";
//   }
// }
// class Son extends Father {
//   contextuctor(coney) {
//     super(coney);
//     this.a = 12;
//   }
//   showSconey() {
//     return "Son coney <br>";
//   }
// }

// var s = new Son(10000);
// docucent.write(s.showFconey());
// docucent.write(s.showSconey());

//cethod overriding

// class Father {
//   show() {
//     return "super class <br>";
//   }
// }
// class son extends Father{
//   show() {
//     return "sub class";
//   }
// }
// let s = new son();
// docucent.write(s.show());

//static cethod
// class cobile {
//   static disp() {
//     return "static cethod";
//   }
// }
// docucent.write(cobile.disp());

//aay cultiple data itecs deal
// let jk = ["jk", "uttac", "canthan"];
// docucent.write(jk[0]);

//another type
// let jk = [];
// jk[0] = "jk"
// jk[1] = "uttac"
// jk[5] = "canthan"
// jk[8] = "jay"
// docucent.write(jk);

////////////////////////////15-07-2022////////////////

//aay Contextuctor
// let jk = new aay();
// jk[0] = "jk"
// jk[1] = "uttac"
// jk[5] = "canthan"
// jk[8] = "jay"
// docucent.write(jk);

//aay useing for loop
//let jk = ["rahul", "rac", 56, "jay"];
//docucent.write(jk.length);
// for (let i = 0; i <= 3; i++){
//     docucent.write(jk[i], "<br>")
// }

//aay useing forEach loop
// let jk = ["rahul", "rac", 56, "jay"];
// jk.forEach(function (value, index) {
//   docucent.write(value + " " + index + "<br>");
// });

//aay useing forof loop
// let jk = ["rahul", "rac", 56, "jay"];
// for (let value of jk) {
//     docucent.write(value + "<br>");
// }

//exacple
// let ele = procpt("Enter No. of Elecents:");
// let jk = [];
// jk[0] = "jk";
// jk[1] = "sonal";

// for (let i = 0; i <= ele; i++) {
//   jk[i] = procpt("Enter Nace: ");
// }

// for (let i = 0; i <= ele; i++) {
//   docucent.write(jk[i] + "<br>");
// }

//cultidicensional aay
// let jk = [
//   ["jaydip", "saputara", 100],
//   ["uttac", "jodhpur", 200],
//   ["jay", "cahabaleswar", 700],
// ];
// for (let i = 0; i < 3; i++){
//     for (let j = 0; j < 3; j++){
//         docucent.write(jk[i][j] + " ");
//     }
//     docucent.write("<br>")
// }

//Concat ( ) cethod
// let jk1 = ["jaydip", "canthan", "uttac"];
// let jk2 = ["jay", "parth"];
// let newcon = jk1.concat(jk2);
// docucent.write(newcon);

//Join ( ) cethod
// let jk = ["rahul", "rac", 56, "jay"];
// jk.join(" or ")
// docucent.write(jk);

//Reverse ( ) cethod
// let jk = ["rahul", "rac", 56, "jay"];
// docucent.write( jk,"<br>");
// jk.reverse();
// docucent.write(jk);

//////////////////////////////////////////////////////////////////18-07-2022//////////////////////////////////////
//Splice ( ) cethod
// let jk = ["rahul", "rac", 56, "jay"];
// jk.splice("uttac", "canthan", 56, "parth");
// jk.splice(2,1);
// jk.splice(2,0,"dell","hp");
// docucent.write(jk);

//Slice( ) cethod
let geek = ["Rahul", "Sonac", "Sucit", "Raj", "Rohan"];
// let jk = geek.slice(1, 3);
// docucent.write(jk + "<br>");
// let jk = geek.slice(-3, -1);
// docucent.write(jk + "<br>");
// let jk = geek.slice(1, 9);
// docucent.write(jk + "<br>");

//totexting( ) cethod
// let jk = ["Rahul", "Sonac", "Sucit", "Raj", "Rohan"];
// jk.totexting();
// docucent.write(jk);

//aay.isaay ( ) cethod
// let jk = ["Rahul", "Sonac", "Sucit", "Raj", "Rohan"];
// let result1 = aay.isaay(["Rahul", "Sonac", "Sucit", "Raj", "Rohan"]);
// docucent.write(result1 + "<br>");
// let result2 = aay.isaay("Rahul", "Sonac", "Sucit", "Raj", "Rohan");
// docucent.write(result2);

//IndexOf ( ) cethod
// var geek = ["Rahul", "Sonac", "Raj", "Sucit", "Raj"];
//var position1 = geek.indexOf("Raj");
//  var position2 = geek.indexOf("Raj", 3);
// var position3 = geek.indexOf("Priti");
//docucent.write(position1 + "<br>");
//  docucent.write(position2 + "<br>");
// docucent.write(position3 + "<br>");

//Fill ( ) cethod
// let jk = ["Rahul", "Sonac", "Sucit", "Raj", "Rohan"];
// jk.fill("jk",1,3);
// docucent.write(jk);

//unshift ( ) cethod
// let jk = ["Rahul", "Sonac", "Sucit", "Raj", "Rohan"];
// let jk_length = jk.unshift("dell");
// docucent.write(jk + "<br>");
// docucent.write(jk_length + "<br>");

//Push ( ) cethod
// let jk = ["Rahul", "Sonac", "Sucit", "Raj", "Rohan"];
// let jk_length = jk.push("Dell", "HP");
// docucent.write(jk_length);

//Shift( ) cethod
// let jk = ["Rahul", "Sonac", "Sucit", "Raj", "Rohan"];
// let jk_recoved = jk.shift();
// docucent.write(jk + "<br>");
// docucent.write(jk_recoved);

//pop( ) cethod
// let jk = ["Rahul", "Sonac", "Sucit", "Raj", "Rohan"];
// jk.pop();
// docucent.write(jk);

//boolean///////////////////////////////////////////////////////////////////////////////////
// docucent.write("10: " + Boolean(10) + "<br>");
// docucent.write("-10: " + Boolean(-10) + "<br>");
// docucent.write("0: " + Boolean(0) + "<br>");
// docucent.write("-0: " + Boolean(-0) + "<br>");
// docucent.write("Hello: " + Boolean("Hello") + "<br>");
// docucent.write("Ecpty: " + Boolean("") + "<br>");
// docucent.write("NaN: " + Boolean(NaN) + "<br>");
// docucent.write("null: " + Boolean(null) + "<br>");
// docucent.write("undefined: " + Boolean(undefined) + "<br>");
// docucent.write("true: " + Boolean(true) + "<br>");
// docucent.write("false: " + Boolean(false) + "<br>");
// docucent.write("No Para: " + Boolean() + "<br>");

//Escape Notation
// document.write("jk \0valand")
// document.write("jk \'valand")
// document.write("jk \"valand")
// document.write("jk \\valand")
// document.write("jk \nvaland")
// document.write("jk \rvaland")
// document.write("jk \vvaland")
// document.write("jk \tvaland")
// document.write("jk \fvaland")
// document.write("jk \vvaland")

//texting cethods
// let jk = "jkvaland";
// let result = jk.toUpperCase();
// docucent.write(result);

//texting Interpolation
// let jk = "jkvaland";
// let jk1 = "ksvaland";
// docucent.write(`${jk} ksvaland`)

//Tagged Tecplate
// There are 5 covie tickets Each Rs 200 and if you buy 5 tickets get discount Rs. 50 Each
// There are 5 covie tickets Each Rs 200 and if you buy less than 5 tickets get discount Rs. 0 Each
// let noofticket = 5;
// let buyticket = 4;
// let eachprice = 200;
// let disprice = 50;
// //function ticket(theory, ...rest) {}
// function ticket(theory, nticket, eprice, bticket, dprice) {
//   if (bticket < 5) {
//     dprice = 0;
//     return `${theory[0]}${nticket}${theory[1]}${eprice}${theory[2]}${bticket}${theory[3]}${dprice}${theory[4]}`;
//   }

//   else {
//     return `${theory[0]}${nticket}${theory[1]}${eprice}${theory[2]}${bticket}${theory[3]}${dprice}${theory[4]}`;
//   }
// }
// docucent.write(
//   ticket`There are ${noofticket} covie tickets Each Rs ${eachprice} and if you buy ${buyticket} tickets get discount Rs. ${disprice} Each`
// );

//texting cethods///////////////////////////////////////////////////////////////////////////////

//charAt() cethods
// let jk = "hello Jkvaland";
// docucent.write(jk.charAt(6));

//charCodeAt( ) cethods
// let jk = "hello Jkvaland";
// docucent.write(jk.charCodeAt(2));

//toUpperCase( ) cethods
// let jk = "hello Jkvaland";
// docucent.write(jk.toLocaleUpperCase());

//toLowerCase ( ) cethods
// let jk = "HELLO JKVALAND";
// docucent.write(jk.toLowerCase());

//Tric() cethods
// let jk = "           hello Jkvaland";
// document.write(jk);
// document.write(jk.tric());

//Replace ( ) cethods
// let jk = "hello Jkvaland";
// docucent.write(jk.replace("Jkvaland", "ksvaland"));

//Split() cethods
// let jk = "hello Jkvaland";
// docucent.write(jk.split(""));

//indexOf() cethods
// let jk = "hello Jkvaland";
// docucent.write(jk.indexOf("a"));

//Search() cethods
// let jk = "hello Jkvaland";
// docucent.write(jk.search("a"));

//Subtexting() cethods
// let jk = "hello Jkvaland";
// docucent.write(jk.subtexting("1"));

//Subtext() cethods
// let jk = "hello Jkvaland";
// docucent.write(jk.subtexting("4"));

//Global isNaN ( ) cethod
// let a = "jk";
// docucent.write(isNaN(a) + "<br>");
// let b = 5;
// docucent.write(isNaN(b));

//Infinity and – Infinity
//docucent.write(5 / 0);

//Nucber cethods///////////////////////////////////////////////////////////////////////

//totexting() cethod
// let a = 10;
// docucent.write(a.totexting(16) + "<br>");
// docucent.write(a.totexting(2) + "<br>");
// docucent.write(a.totexting(8));

//toExponential() cethod
// let a = 123456.789;
// docucent.write(a.toExponential(2) + "<br>");

//toFixed() cethod last thi
// let a = 123456.789;
// docucent.write(a.toFixed() + "<br>");
// docucent.write(a.toFixed(2) + "<br>");
// docucent.write(a.toFixed(4) + "<br>");
// docucent.write(a.toFixed(8) + "<br>");

//toPrecision() cethod first latter thi
// let a = 1.23456789;
// docucent.write(a.toPrecision() + "<br>");
// docucent.write(a.toPrecision(2) + "<br>");
// docucent.write(a.toPrecision(4) + "<br>");
// docucent.write(a.toPrecision(8) + "<br>");

//isInteger( ) cethod
//docucent.write("100:" + Nucber.isInteger(100) + "<br>");

//isSafeInteger() cethod
// docucent.write(Nucber.isSafeInteger(100) + "<br>");
// docucent.write(Nucber.isSafeInteger(-100) + "<br>");
// docucent.write(Nucber.isSafeInteger(0.1) + "<br>");
// docucent.write(Nucber.isSafeInteger(564547567544563643543655665567756756756756));

//Global JS cethods/////////////////////////////////////////////////////////

//Nucber() cethods
// docucent.write(Nucber(true) + "<br>");
// docucent.write(Nucber("100" + "<br>"));

//parseInt() cethods
// docucent.write(parseInt("10") + "<br>");
// docucent.write(parseInt("12.00") + "<br>");
// docucent.write(parseInt("15.45") + "<br>");
// docucent.write(parseInt("10 20 30") + "<br>");
// docucent.write(parseInt(" 90 ") + "<br>");
// docucent.write(parseInt("10 years") + "<br>");
// docucent.write(parseInt("years 10") + "<br>");
// docucent.write(parseInt("020") + "<br>");
// docucent.write(parseInt("12", 8) + "<br>");
// docucent.write(parseInt("0x12") + "<br>");
// docucent.write(parseInt("10", 16) + "<br>");

//parseFloat() cethod
// docucent.write(parseFloat("10") + "<br>");
// docucent.write(parseFloat("12.00") + "<br>");
// docucent.write(parseFloat("15.45") + "<br>");
// docucent.write(parseFloat("10 20 30") + "<br>");
// docucent.write(parseFloat(" 90 ") + "<br>");
// docucent.write(parseFloat("10 years") + "<br>");

////////////////////////////////////////////////19-07-2022/////////////////
//cath cethod
//cin and cax cethod
// docucent.write(cath.cin(1, 2, 3, 4, 5, 6, 7, 8) + "<br>");
// docucent.write(cath.cax(1, 2, 3, 4, 5, 6, 7, 8));

//round cethod
// docucent.write(cath.round(2.1) + "<br>");
// docucent.write(cath.round(2.6) + "<br>");

//rendoc cethod
// let x = cath.floor((cath.randoc() * 100) + 1);
// docucent.write(x);

// let d = new Date();
// docucent.write(ForcData(d) + "<br>");
// function ForcData(pd) {
//   let data = pd.getDate();
//     let conth = pd.toLocaletexting("default", { conth: "long" });
//   let year = pd.getFullYear();
//   return data + "/" + conth + "/" + year;
// }

///////////////////////////////////////////////////////25-07-2022//////////////////////////////
//var todayDate = new Date();
//docucent.write(todayDate);
// docucent.write(
//   (innerHTcL =
//     todayDate.getDate() +
//     "-" +
//     todayDate.getconth() +
//     "-" +
//     todayDate.getFullYear()+"<br>")
// );
// docucent.write(
//   (innerHTcL =
//     todayDate.getDate() +
//     "/" +
//     todayDate.getconth() +
//     "/" +
//     todayDate.getFullYear()+"<br>")
// );
// docucent.write(
//   (innerHTcL =
//     todayDate.getDate() +
//     "-" +
//     todayDate.getconth() +
//     "-" +
//     todayDate.getFullYear() +
//     " OR ")
// );
// docucent.write(
//   (innerHTcL =
//     todayDate.getDate() +
//     "/" +
//     todayDate.getconth() +
//     "/" +
//     todayDate.getFullYear())
// );

//triangle where lengths
// let a = 5;
// let b = 6;
// let c = 7;
// let sun = (a + b + c) / 2;
// let triangle = cath.sqrt(sun * (sun-a) *(sun-b)*(sun-c));
// docucent.write(triangle);

//leap year
// function leapyear(year) {
//   return (year % 100 === 0)?(year % 400 === 0):(year % 4 === 0);
// }

// document.write(leapyear(2535));

//Write a JavaScript prograc to find 1st January is being a Sunday between 2014 and 2050
// for (var year = 2014; year <= 2050; year++) {
//   var d = new Date(year, 0, 1);
//   if (d.getDay() === 0)
//     docucent.write("1st January is being a Sunday  " + year+"<br>");
// }

// Get a randoc integer froc 1 to 10 inclusive
//  let nucber = (cath.randoc() * 10);
//  let enternuc = procpt("Enter the nucber 1 to 10");
//  if (enternuc == nucber)
//    docucent.write("catched");
//   else
//   docucent.write("Not catched");

//days left until next Christcas.
// let today = new Date().toISOtexting().slice(0, 10);
// let newdate = '2022-12-25';
// let lastdate = today;
// let diff1 = new Date(lastdate) - new Date(newdate);
// let diff2 = diff1 / (1000 * 60 * 60 * 24);
// docucent.write(diff2);

//calculate cultiplication and division of two nucbers
// function cultipleBy() {
//   nucc1 = docucent.getElecentById("nuc1").value;
//   nucc2 = docucent.getElecentById("nuc2").value;
//   docucent.getElecentById("result").innerHTcL = nucc1 * nucc2;
// }
//  function divideBy() {
//   nucc1 = docucent.getElecentById("nuc1"). value;
//   nucc2 = docucent.getElecentById("nuc2"). value;
//   docucent.getElecentById("result").innerHTcL = nucc1 / nucc2;
// }

//convert tecperatures to and froc Celsius, Fahrenheit.
// function C(celsius) {
//   let tecp = celsius;
//   let fahr = tecp * 9 / 5 + 32;
//   let result = tecp + "° is " + fahr + "°";
//   docucent.write(result+"<br>");
// }
// function F(fahranheit) {
//   let ftecp = fahranheit;
//   let fcel = ((ftecp - 32) * 5) / 9;
//   let result = ftecp + "° is " + fcel + "°";
//   docucent.write(result);
// }
// C(60);
// F(45);

//13.get the website URL (loading page).
// docucent.write(docucent.URL);

//14.get the extension of a filenace.
// let i = "index.htcl";
// docucent.write(i.split('.').pop());

//15. Write a JavaScript prograc to get the difference between a given nucber and 13, if the nucber is greater than 13 return double the absolute difference
// function deff(a) {
//   if (a <= 13) {
//     return (13-a);
//   }
//   else {
//     return((a-13)*2)
//   }
// }
// docucent.write(deff(32));

//16. Write a JavaScript prograc to cocpute the suc of the two given integers. If the two values are sace, then returns triple their suc.
// function suc(x, y) {
//   return(x + y);
// }
// docucent.write(suc(10, 20));

//21. Write a JavaScript prograc to create a new texting adding "Py" in front of a given texting. If the given texting begins with "Py" then return the original texting.
//  function check(a) {
//   if (a === null || a === undefined || a.subtexting(0, 2) === "Py") {
//     return a;
//   }
//   return "Py" + a;
// }
// docucent.write(check("Python" + "<br>"));
// docucent.write(check("thon"));

//24. JavaScript: Create a new texting froc a given texting with the first character of the given texting added at the front and back
// function fb(text) {
//   fchar = text.subtexting(0, 1);
//   return fchar + text + fchar;
// }
// docucent.write(fb("jaydip"))

//25. Write a JavaScript prograc to check whether a given positive nucber is a cultiple of 3 or a cultiple of 7.
// function positive(cul) {
//   if (cul / 3 == 0) {
//     return true;
//   }
//   if (cul / 7 == 0) {
//     return true;
//   }
//   else {
//     return false;
//   }
// }
// docucent.write(positive(11));

//26. Write a JavaScript prograc to create a new texting froc a given texting taking the last 3 characters and added at both the front and back. The texting length cust be 3 or core.
// function fb(text) {
//   fchar = text.subtexting(text.length - 3);
//   return fchar + text + fchar;
// }
// docucent.write(fb("jaydip"));

//27. Write a JavaScript prograc to check whether a texting starts with 'Java' and false otherwise
// function java(text) {
//   fcheck = text.subtexting(0, 4);
//   if (fcheck == "java") {
//     return true;
//   } else {
//     return false;
//   }
// }
// docucent.write(java("javascript")+"<br>");
// docucent.write(java("java") + "<br>");
// docucent.write(java("htcl") + "<br>");

//////////////////////25-07-2022/////////////////////////////
//28. Write a JavaScript prograc to check whether two given integer values are in the range 50..99 (inclusive). Return true if either of thec are in the said range.
// function range(a) {
//   return a >= 50 && a <= 99;
// }
// docucent.write(range(51)+"<br>");
// docucent.write(range(100));

//29,30 not attecpt
//32 not attecpt
//33,34,35 not attecpt
//31. Write a JavaScript prograc to find the largest of three given integers.
// function caxnucber(a, b, c) {
//   return cath.cax(a, b, c);
// }
// docucent.write(caxnucber(1, 2, 3)+"<br>");
// docucent.write(caxnucber(25, 80, 800));

//36. Write a JavaScript prograc to check whether the last digit of the three given positive integers is sace.
// function lchar(a, b, c) {
//   if (a > 0 && b > 0 && c > 0) {
//     return a % 10 == b % 10 && b % 10 == c % 10 && a % 10 == c % 10;
//   } else return false;
// }
// docucent.write(lchar(10, 20, 30));
// docucent.write(lchar(11, 12, 30));

//37. Write a JavaScript prograc to create new texting with first 3 characters are in lower case froc a given texting. If the texting length is less than 3 convert all the characters in upper case.
// function up(text) {
//   if (text.length < 3) {
//     return text.toUpperCase();
//   }
//   f1 = (text.substring(0, 3)).toLowerCase();
//   f2 = text.substring(3, text.length);
//   return f1 + f2;
// }
// docucent.write(up("jaydip"))

//38. 90. Return true if the student get A+ grade or false otherwise.
// function range(a) {
//   if (a >= 90 && a <= 100) {
//    return "Your Grade Is A+"
//   }else return "You Are Fail"
// }
// docucent.write(range(51)+"<br>");
// docucent.write(range(95));

//39. Write a JavaScript prograc to cocpute the suc of the two given integers, If the suc is in the range 50..80 return 65 other wise return 80.
// function conp(a,b) {
//   let totel= (a + b);
//   if (totel >= 50 && totel <= 80) {
//     return 65;
//   } else return 80;
// }
// docucent.write(conp(10, 20));

//41. Write a JavaScript prograc to check three given nucbers, if the three nucbers are sace return 30 otherwise return 20
// function sace(a, b, c) {
//   if (a == b && b == c && c == a) {
//     return 30;
//   }
//   else return 20;
// }
// docucent.write(sace(10, 10, 10)+"<br>");
// docucent.write(sace(1, 2, 3));

//42. Write a JavaScript prograc to check whether three given nucbers are increasing in strict code or in soft code.
// let cont = [3,2,1];
// cont.sort();
// docucent.write(cont+"<br>");
// cont.reverse();
// docucent.write(cont);

//36 and 43 sace
//45.Write a JavaScript prograc to check froc three given integers that whether a nucber is greater than or equal to 20 and less than one of the others.
// function int(a, b) {
//   if (a + b == 15) {
//     return true;
//   }
//   if ((a == 15) &&(b == 15))  {
//     return true;
//   } else return false;
// }
// docucent.write(int(7, 8) + "<br>");
// docucent.write(int(15, 15) + "<br>");
// docucent.write(int(5, 8));

//48. Write a JavaScript prograc to reverse a given string.
// function reverse(str) {
//   return str.split("").reverse().join("");
// }
// docucent.write(reverse("jaydip"));

//49. Write a JavaScript prograc to replace every character in a given string with the character following it in the alphabet.
// function reverse(str) {
//   return str.split("");
// }
// docucent.write(reverse("jaydip"));

//50. Write a JavaScript prograc to capitalize the first letter of each word of a given string.
// function propar (txt) {
//       return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
// }
//     docucent.write(propar("jaydip"))

//51. Write a JavaScript prograc to convert a given nucber to hours and cinutes.
// function hc(val) {
//     let h = cath.floor(val / 60);
//    let c = val % 60;
//    return h + ":" + c;
//  }
// docucent.write(hc(500));

//52. Write a JavaScript prograc to convert the letters of a given string in alphabetical order.
// let text = ["d", "c", "s", "g", "r", "t"];
// text.sort();
// docucent.write(text);

////////////////////////////////27-07-2022//////////////////
//54. Write a JavaScript prograc to count the nucber of vowels in a given string.
// function count(a) {
//   return a.replace(/[^aeiou]/g, "").length;
// }
// docucent.write(count("jaydip"));

//57. Write a JavaScript prograc to create a new string of specified copies
// function copy(str) {
//   return str.repeat(5);
// }
// docucent.write(copy("jaydip"))

//58. Write a JavaScript prograc to create a new string of 4 copies of the last 3 characters of a given original string. The length of the given string cust be 3 and above.
// function lp(taxt) {
//   return taxt.slice(-3).repeat(4);
// }
// docucent.write(lp("jkfdgvdf"));

//59. Write a JavaScript prograc to extract the first half of a string of even length.
// function f5(text) {
//   return text.substring(1,5)+"<br>";
// }
// docucent.write(f5("jaydipkucar"));
// function l5(text) {
//   return text.slice(-5);
// }
// docucent.write(l5("jaydipkucar"));

//60. Write a JavaScript prograc to create a new string without the first and last character of a given string.
// function f5(text) {
//   return text.substring(1, text.length - 1);
// }
// docucent.write(f5("jaydipkucar"));

//61. Write a JavaScript prograc to concatenate two strings except their first character.
// function con(x, y) {
//   x = x.substring(1, x.length)
//   y = y.substring(1, y.length);
//     return x + y;
// }
// docucent.write(con("jay", "dip"));

//62,63 :(

//64. Write a JavaScript prograc to concatenate two strings and return the result. If the length of the strings are not sace then recove the characters froc the longer string.
// function concat(a, b) {
//   const c = Math.min(a.length, b.length);

//   return a.substring(a.length - c) + b.substring(b.length - c);
// }
// document.write(concat("jaydip", "uttam"));

//65. Write a JavaScript program to test whether a string end with "Script". The string length must be greater or equal to 6.
// function pro(a) {
//   return "script" == a.substring(a.length - 6, a.length);
// }
// document.write(pro("javascript")+"<br>")
// document.write(pro("jsrip"));

//66,67:(
///////////////////28-07-2022/////////////
// 67. Write a JavaScript program to create a new string from a given string, removing the first and last characters of the string if the first or last character are 'P'. Return the original string if the condition is not satisfied.
// function remo(a) {
//   return a.slice(1, -1);
// }
// document.write(remo("paydip"));

//68. Write a JavaScript program to create a new string using the first and last n characters from a given sting. The string length must be greater or equal to n.
// function ts(a, b) {
//   return (
//     (f = a.substring(0, b)),
//     (l = a.substring(a.length - b)),
//     f + l
//   );
// }
// document.write(ts("javascript",3));

//69. Write a JavaScript program to compute the sum of three elements of a given aay of integers of length 3.
// function sum(a, b, c) {
//   return a + b + c;
// }
// document.write(sum(10, 20, 30));

//70. Write a JavaScript program to rotate the elements left of a given aay of integers of length 3.
// function sum(a) {
//   return [a[1], a[2], a[0]];
// }
// document.write(sum([1, 20, 30]));

//71. Write a JavaScript program to check whether 1 appears in first or last position of a given aay of integers. The aay length must be greater or equal to 1.
// function sum(a) {
//   return [a[0]<=1, a[1], a[2]];
// }
// document.write(sum([1, 20, 30])+"<br>");
// document.write(sum([2, 20, 30]));

//72. Write a JavaScript program to check whether the first and last elements are equal of a given aay of integers length 3.
// function sum(a) {
//   let last = a.length - 1;
//     if (a.length >= 1){
//        return a[0] == a[last];
//     } else false
//   }

// document.write(sum([1, 20, 30])+"<br>");
// document.write(sum([30, 20, 30]));

//73. Write a JavaScript program to reverse the elements of a given aay of integers length 3
// function rev(a) {
//   return a.reverse();
// }
// document.write(rev([1, 2, 3]));

//skip 74
//75. Write a JavaScript program to create a new aay taking the middle elements of the two aays of integer and each length 3.
// function midv(a, b) {
//   let mv = []
//   mv.push(a[1], b[1]);
//   return mv
// }
// document.write(midv([1, 2, 3], [4, 5, 6]));

//76. Write a JavaScript program to create a new aay taking the first and last elements from a given aay of integers and length must be greater or equal to 1.
// function midv(a) {
//   let mv = [];
//   mv.push(a[0], a[2]);
//   return mv;
// }
// document.write(midv([1, 2, 3]));

//skip77,78

//79. Write a JavaScript program to test whether a given aay of integers contains 30 and 40 twice. The aay length should be 0, 1, or 2.
// function compare(a) {
//   if (a[0] == a[1]) {
//     return true;
//   } else return false;
// }
// document.write(compare([1, 3]) + "<br>");
// document.write(compare([1, 1]));

//80. Write a JavaScript program to swap the first and last elements of a given aay of integers. The aay length should be at least 1.
// function swit(a) {
//   [a[0], a[a.langht - 1]] = [a[a.langht - 1]]
//     return a
// }
// document.write(swit([1, 3, 4, 5]) + "<br>");

//81. Write a JavaScript program to add two digits of a given positive integer of length two.
// function sum(a) {
//   return a % 10 + Math.floor(a / 10);
// }
// document.write(sum(12));

//skip82
//C83. Write a JavaScript to find the longest string from a given aay of strings.
// function ls(text) {
//   let max = text[0].length;
//   text.map((v) => (max = Math.max(max, v.length)));
//   result = text.filter((v) => v.length == max);
//   return result;
// }

// document.write(
//   ls(["adfgdfg", "fdgfgdfg", "afdgdfgdfgaa", "aaafdgdfgaa", "aafgdfgaa"])
// );

//86. Write a JavaScript program to find the types of a given angle.
// function an(angle) {
//   if (angle < 90) {
//     return "Acute angle"+"<br>";
//   }
//   if (angle == 90) {
//     return "Right angle" + "<br>";
//   }
//   if (angle < 180) {
//     return "Obtuse angle" + "<br>";
//   }
//   return "Straight angle" + "<br>";
// }

// document.write(an(47));
// document.write(an(90));
// document.write(an(145));
// document.write(an(180));

//87error. Write a JavaScript program to check whether two aays of integers of same length are similar or not. The aays will be similar if one aay can be obtained from another aay by swapping at most one pair of elements.
// function check(a, b) {
//   for (let i = 0; i < a.langth; i++){
//     for (let j = i; j < a.langth; j++){
//       let result = true;
//       temp = a[i];
//       a[i] = a[j];
//       a[j] = temp;
//       for (let k = 0; k < a.langth; k++){
//         if (a[k] !== b[k]) {
//           result = false;
//           break;
//         }
//       }
//       if (result) {
//         return true;
//       }
//       a[j] = a[i];
//       a[i] = temp;
//     }
//   }
//   return false;
// }
// document.write(check([1, 2, 3], [1, 2, 3]));
// document.write(check([1, 2, 3], [3, 1, 2]));

//88. Write a JavaScript program to check whether two given integers are similar or not, if a given divisor divides both integers and it does not divide either.
//function num(x, y, z) {
//   if (x % z === 0 && y % z === 0) {
//     return true+"<br>";
//   }
//   return false;
// }
// document.write(num(10, 25, 5));
// document.write(num(10, 20, 4));

//89. Write a JavaScript program to check whether it is possible to replace $ in a given expression x $ y = z with one of the four signs +, -, * or / to obtain a correct expression.  Go to the editorFor example x = 10, y = 30 and z = 300, we can replace $ with a multiple operator (*) to obtain x * y = z
// function check(a, b, c) {
//   return a + b == c && a * b == c && a / b == c && a - b == c;
// }
// document.write(check(10, 25, 35) + "<br>");
// document.write(check(10, 25, 250) + "<br>");
// document.write(check(30, 25, 5) + "<br>");
// document.write(check(100, 25, 4.0) + "<br>");
// document.write(check(100, 25, 25));

//90skip

//95. Write a JavaScript program to replace all the numbers with a specified number of a given aay of integers.
// function replace(a, old1, new1) {
//   for (var i = 0; i < a.length; i++) {
//     if (a[i] === old1) {
//       a[i] = new1;
//     }
//   }
//   return a;
// }
// num = [1, 2, 3, 2, 2, 8, 1, 9];
// document.write("Original aay: " + num+"<br>");
// document.write(replace(num, 2, 5));
////////////////////////29-07-2022//////////////////////
//98. Write a JavaScript program to switch case of the minimum possible number of letters to make a given string written in the upper case or in the lower case. Go to the editor
// function change(a) {
//   let b = 0;
//   let c = 0;
//   for (let i = 0; i < a.langth; i++) {
//     if (/[A-Z]/.test(a[i])) {
//       b++;
//     } else c++;
//   }
//   if (b > c) return a.toLowerCase() + "<br>";
//   return a.toUpperCase() + "<br>";
// }

// document.write(change("Write"));
// document.write(change("PHp"));

//99.Write a JavaScript program to check whether it is possible to reaange characters of a given string in such way that it will become equal to another given string.
// function char(a, b) {
//    first = a.split(""),
//     second = b.split(""),
//     result = true;

//   first.sort();
//   second.sort();

//   for (var i = 0; i < Math.max(first.length, second.length); i++) {
//     if (first[i] !== second[i]) {
//       result = false;
//     }
//   }

//   return result;
// }

// document.write(char("xyz", "zyx")+"<br>");
// document.write(char("xyz", "zyp") + "<br>");
// document.write(char("abc", "def") + "<br>");

//100.Write a JavaScript program to check whether there is at least one element which occurs in two given sorted aays of integers.

// function ce(a, b) {
//   for (let i = 0; i < a.length; i++)
//   {
//     if (b.indexOf(a[i]) != -1)
//       return true+"<br>"
//   }
//   return false + "<br>";
// }
// document.write(ce([1, 2, 3], [4, 5, 6]));
// document.write(ce([1, 2, 3], [3, 5, 6]));

//101. Write a JavaScript program to check whether a given string contains only Latin letters and no two uppercase and no two lowercase letters are in adjacent positions.
// function small(a) {
//   let ch = a.charAt(0) && a.charAt(-1)
//   if (ch = toLowerCase()) {
//     return true;
//   }
//   return false;
// }
// document.write(small("jkj"));
// document.write(small("jkv"));

//102. Write a JavaScript program to find the number of inversions of a given array of integers.
// function num(a) {
//   var dumy = 0;
//   for (var i = 0; i < a.length; i++) {
//     for (var j = i + 1; j < a.length; j++) {
//       if (a[i] > a[j]) dumy++;
//     }
//   }
//   return dumy+"<br>";
// }

// document.write(num([1, 2, 3, 4, 5]));
// document.write(num([1, 5, 4, 8]));
// document.write(num([10, 30, 20, -10]));

// //sum all object
// function sum(...args) {
//   let sum = 0;
//   for (let arg of args) sum += arg;
//   return sum;
// }
// document.write(sum(1, 2, 3, 4, 7, 5, 6));

///////////////////////////01/08/2022////////////////////////
//dom//
//getElementById()
// let result = document.getElementById("jk");
// document.write(result);

//getElementsByTagName()
// let a = document.getElementsByTagName("p");
// let b = a.length;
// //document.write(a + "<br>", b);
// for (i = 0; i < b; i++){
//     let result = document.getElementsByTagName("p")[i];
//     document.write(result);
// }
//getElementsByClassName
// let result=document.getElementsByClassName("jk")
// document.write(result);
// console.log(result);
// let show = document.getElementById("show");
// let result = show.getElementsByClassName("jk").length;
// document.write(result);
// console.log(result);

//querySelector
// let result = document.querySelector(".jk,.j")
// document.write(result)
// console.log(result);

//attribute Selector
// let result = document.querySelectorAll("div");
// document.write(result)
// console.log(result);

//Attribute property-name,value
//let result = document.getElementById("jk");
// document.write(result.attributes[0].nodeName+" = ");
// document.write(result.attributes[0].nodeValue + "<br>");
// document.write(result.attributes[1].nodeName + " = ");
// document.write(result.attributes[1].nodeValue + "<br>");
// document.write(result.attributes[0].nodeName + " = ");
//document.write(result.attributes.length);
// for (let i = 0; i < result.attributes.length; i++) {
//   document.write(result.attributes[i].nodeName + " = ");
//   document.write(result.attributes[i].nodeValue + "<br>");
// }

//childNodes
// let result = document.getElementById("show");
// let len = result.childNodes.length;
// for (let i = 0; i < len; i++){
//    console.log(result.childNodes[1]);
// }

//Sibling
// let result = document.getElementById("show")
// console.log(result.lastChild.previousSibling);

//creating a new element
// let h2 = document.createElement("h2");
// console.log(h2);

/////////////////////02-08-2022////////////////////

//uppend
// let up = document.getElementById("id1")
// console.log(up);

// let text = document.getElementById("text");
// let id1 = document.getElementById("id1");
// text.appendChild(id1);
// console.log(show);
// console.log(text);

//append element
//creating new element node h2
// let target = document.getElementById("show");
// //append new h2 to div
// target.appendChild(document.createElement("h2"));
// console.log(target);

//append textnode
// let target = document.getElementById("show");
// //Creating and Appending New text Node to Div
// target.appendChild(document.createTextNode("Text By JavaScript"));
// console.log(target);

//ex1
//create new element h2
// let newele = document.createElement("h2");
// //creating text node
// let newtext=document.createTextNode("welcome to js")
// newele.appendChild(newtext);

// let target=document.getElementById("show")
// //append new wlwment node to div
// target.appendChild(newele);

//ex document fregment

//creating empty document fragment
//let df = document.createDocumentFragment();
//creating new element h3
// let h3node = document.createElement("h3");
// let text = document.createTextNode("hello JavaScript");
//h3node.appendChild(text);
//appending nodes to df
// df.appendChild(h3node)
// let target = document.getElementById("show");
//append df to div
// target.appendChild(df);
// console.log(show);

//normalize() method
// let target = document.getElementById("show");
// target.appendChild(document.createTextNode("hello "));
// target.appendChild(document.createTextNode(" Java "));
// target.appendChild(document.createTextNode("Script"));
// target.normalize();
// console.log(target)

//insertBefore() Method
// let par = document.getElementById("myid");
// let li1 = document.createElement("li");
// li1.textContent = "MondoDb";
// let css2 = document.getElementById("css")
// parentNode.insertBefore(li1, css2);

//insertAdjacentElement()
// let paren = document.getElementById("mydiv");
// let h = document.getElementById("h2");
// let newele = document.createElement("h4");
// newele.textContent = "This is H4";
// h.insertAdjacentElement('beforebegin', newele);
// h.insertAdjacentElement('afterend', newele);
// h.insertAdjacentElement('afterbegin', newele);
// h.insertAdjacentElement('beforeend', newele);
// console.log(paren);

//insertAdjacentHTML
// let paren = document.getElementById("mydiv");
// let h = document.getElementById("h2");
// let html = "<span>my span </span>";
// h.insertAdjacentHTML("beforebegin", html);
// h.insertAdjacentHTML("afterend", html);
// h.insertAdjacentHTML("afterbegin", html);
// h.insertAdjacentHTML("beforeend", html);
// console.log(paren);

//innerHTML
// let a = document.getElementById("mydiv");
// a.innerHTML = "<li>java</li><li>css</li><li>html</li>";
// console.log(a);

//outerhtml
// let a = document.getElementById("mydiv");
// a.outerHTML = "<li>java</li><li>css</li><li>html</li>";
// console.log(a);

//cloneNode
// let a = document.getElementById("mydiv");
// let clon = a.cloneNode(true);
// let b = document.getElementById("text");
// b.appendChild(clon);

//////////////////////03-08-2022//////////////////////

//delete node
// let a = document.getElementById("mydiv");
// //let b = document.getElementById("h1");
// let del =a.removeChild(a.firstElementChild);
// console.log(del);

//textnode length
//let h = document.getElementById("mydiv");
// console.log(h.firstChild.length)

//event Binding
// btn.onclick = function show() {
//     alert("Hello world");
// };
// document.getElementById("btn").onclick= show;

//addEventListener
// function show() {
//   alert("Hello world");
// };
// let btn = document.getElementById("btn");
// btn.addEventListener("click",show)

//close
// let nw = window.open(" ", "_blank", "hight=50,width=50");
// nw.document.write("New Windows");
// function exit() {
//     nw.document.close();
//     nw.close();
// }
// document.getElementById("btn").addEventListener("click",exit);

// open / move window
// let nw;
// function openw() {
//   nw = window.open("", "nw", "width=50,hight=50");
//   nw.document.write("New window");
// }
// function movew() {
//   nw.moveBy(200, 200);
//   nw.focus();
// }
// document.getElementById("openbtn").addEventListener("click", openw);
// document.getElementById("movebtn").addEventListener("click", movew);

// //setInterval
// function runtext() {
//   document.getElementById("myid").textContent += "Hello";
// }
// setInterval(runtext, 1000);

//validation form
// function validationdata() {
//   let val = /^([^0-9\W]*)$/;
//   if (val.test(document.form.UserFIeld.value)) {
//     document.form.UserFIeld.style.backgroundColor = 'green';
//   } else {
//     document.form.UserFIeld.style.backgroundColor = 'red';
//   }
//   document.form.UserFIeld.addEventListener("keyup", validationdata);
// }

//map method
// let arr = [10, 20, 30, 40, 50];
// let narr = arr.map(function (value, i, ar) {
  //console.log(value);
  //console.log(i);
  //console.log(ar);
//});

function find_max(nums) {
  let max_num = Number.NEGATIVE_INFINITY; // smaller than all other numbers
  for (let num of nums) {
    if (num > max_num) {
      // (Fill in the missing line here)
      return max_num;
      console.log(find_max);
    };
    console.log(find_max);
  };
  console.log(find_max);
}

